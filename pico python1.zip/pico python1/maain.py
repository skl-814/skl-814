from machine import Pin
import time

sound = Pin(0,Pin.OUT)
sound.value(1)

ledr = Pin(2,Pin.OUT)
ledg = Pin(3,Pin.OUT)
ledb = Pin(4,Pin.OUT)
in1 = Pin(16,Pin.IN,Pin.PULL_DOWN)

led1 = Pin(25,Pin.OUT)

def Right(x):
    while x == 1:
        led1.value(1)
        sound.value(0)
        time.sleep_ms(500)
        led1.value(0)
        sound.value(1)
        if x == 0:
            sound.value(0)
            led1.value(0)

Right(1)

while True:
    ledr.value(1)
    time.sleep_ms(250)
    ledr.value(0)
    time.sleep_ms(100)
    ledg.value(1)
    time.sleep_ms(250)
    ledg.value(0)
    time.sleep_ms(100)
    ledb.value(1)
    time.sleep_ms(250)
    ledb.value(0)
    time.sleep_ms(100)