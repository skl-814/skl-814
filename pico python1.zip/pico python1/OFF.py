from machine import Pin
import time

pin1 = Pin(25,Pin.OUT)
for aa in range(0,10+1):
    pin1.value(1)
    time.sleep(0.25)
    pin1.value(0)
time.sleep_ms(500)
print("'OFF' is begin")
for a in range(0,26):
    print("\tOffing Pin",a,end=".\n")
    pin1 = Pin(a,Pin.OUT)
    pin1.value(0)

    pin1 = Pin(0,Pin.OUT)
    pin1.value(1)