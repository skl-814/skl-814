from machine import Pin
import time

pin_up = Pin(16,Pin.IN,Pin.PULL_DOWN)
pin_down = Pin(17,Pin.IN,Pin.PULL_DOWN)
pin_l = Pin(18,Pin.IN,Pin.PULL_DOWN)
pin_r = Pin(19,Pin.IN,Pin.PULL_DOWN)

def location():
    while True:

        if pin_up == 1:
            time.sleep_ms(250)
            up = 1
        elif pin_up == 0:
            time.sleep_ms(250)
            up = 0

        if pin_down == 1:
            time.sleep_ms(250)
            down = 1
        elif pin_down == 0:
            time.sleep_ms(250)
            down = 0

        if pin_l == 1:
            time.sleep_ms(250)
            lift = 1
        elif pin_l == 0:
            time.sleep_ms(250)
            lift = 0

        if pin_r == 1:
            time.sleep_ms(250)
            right = 1
        elif pin_r == 0:
            time.sleep_ms(250)
            right = 0


        if up == 1 and down == 1:
            time.sleep_ms(250)
            pass
        elif up == 1 and down == 0:
            time.sleep_ms(250)
            up = True
            down = False
            l = False

        elif up == 0 and down == 1:
            down = False