from machine import Pin
import time
pin_1 =Pin(25,Pin.OUT)
pin_sound = Pin(0,Pin.OUT)
def Right(x):
    while x == 1:
        pin_1.toggle()
        time.sleep_ms(100)# 10Hz
        pin_sound.value(1)
    if x == 0:
        pin_1.value(0)
        pin_sound.value(0)
Right(1)

pin_in = Pin(1,Pin.IN,Pin.PULL_DOWN)
led_r = Pin(2,Pin.OUT)
led_g = Pin(3,Pin.OUT)
led_b = Pin(4,Pin.OUT)

while True:
    if pin_in.value() == 0:
        print("sdk")
        led_g.value(0)
        led_b.value(0)
        led_r.toggle()
    if pin_in.value() == 1:
        print("in : True")
        led_r.value(0)
        led_g.value(1)
        time.sleep_ms(500)
        led_g.value(0)
        time.sleep_ms(350)
        led_b.value(1)
