import os

aaip = input("IP:\n")
bbip = "ping" + " " + aaip
while True:
    os.system(bbip)