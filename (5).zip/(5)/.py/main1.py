import os
while True:
    os.system('ping mi.com')