import os
for a in range(100+1):
    aa = f"main1 - 副本 ({a}).pyc"
    os.system(f"python C:\\Users\\LENOVO\\Desktop\\(5)\\.pyc\\main1.pyc {aa}")