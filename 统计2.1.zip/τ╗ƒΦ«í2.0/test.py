bb = set(numlist)
bb = list(bb)
aab = len(bb)
cc = {}
for x in range(len(bb)+1):
    with open(str(x)+".txt","w") as f:
        ac = x-1
        abc = str(bb[ac])+"\n"
        f.write(abc)
del f
sdf = list(range(len(bb)+1))
for qwe in range(aab+1):
    sdf[qwe-1] = int(sdf[qwe-1])
for ax in bb,sdf:
    for bx,cx in aa,sdf:
        if ax == bx:
            with open(str(cx)+".txt","a") as f:
                f.write("1")
del f
for bx in range(len(bb)+1):
    with open(str(bx)+".txt") as f:
        lines = f.readlines()
        cc[lines[1]] = len(lines[0])
ay = max(float(cc.keys()))
ayy = str(ay)
print("众数：\n",float(cc[ayy]))
d7 = cc[ayy]
