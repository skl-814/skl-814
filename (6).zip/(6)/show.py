import numpy as np
from PIL import Image 
import matplotlib. pyplot as plt 
import string, os, time 
