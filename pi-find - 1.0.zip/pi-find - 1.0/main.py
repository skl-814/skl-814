#!usr/bin/var python
with open("import/pi_million_digits.txt") as fpi:
    pi1 = fpi.readlines()

pi2 = ""
for pi3 in pi1:
    pi2 += pi3.strip()

print("This program is used to test whether your birthday is "
"in or not in the first milion digits of pi(Input 'q' to quit.)")
while True:
    day = input("Day(yymmdd):\n")
    if day.strip() != "q":
        import json
        day2 = day.strip()
        with open("import/import.json","a") as fim:
            json.dump(day2,fim)
        if day2 in pi2:
            print("lucky! Your birthday is in the first milion digits of pi!\n")
        elif day2 not in pi2:
            print("Sorry,your birthday is'n in the first milion digits of pi.\n")
        con = input("Input 'c' to continue.\n")
        if con != "c":
            break
    elif day.strip() == "q":
        print("Thanks for use.")
        break